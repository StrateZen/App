import { createClientFromRequest } from 'npm:@base44/sdk@0.8.4';
import { format, startOfMonth, endOfMonth, subMonths } from 'npm:date-fns@3.6.0';

const ACTIVITY_CODES = {
  '91A': 'Vessel Safety Checks',
  '91H': 'VSC Paddlecraft',
  '91B': 'Vessel Facility Inspections',
  '91C': 'Commercial Fishing Vessel Exams',
  '91D': 'Uninspected Passenger Vessel Exams',
  '91G': 'Uninspected Towing Vessel Exams',
  '99A': 'Auxiliary Leadership',
  '99B': 'RBS Support',
  '99C': 'Marine Safety Support',
  '99D': 'Training Support',
  '99E': 'Administrative/Logistical Support'
};

function generateUserReport(activities, userName) {
  const aggregated = activities.reduce((acc, activity) => {
    const code = activity.activity_code || 'Unknown';
    if (!acc[code]) {
      acc[code] = {
        code,
        name: ACTIVITY_CODES[code] || 'Unknown',
        hours: 0,
        mileage: 0,
        expenses: 0,
        missions: []
      };
    }
    acc[code].hours += activity.total_hours || 0;
    acc[code].mileage += activity.mileage || 0;
    acc[code].expenses += activity.non_reimbursed_expenses || 0;
    acc[code].missions.push(activity.activity_mission);
    return acc;
  }, {});

  const aggregatedArray = Object.values(aggregated);
  const totals = {
    hours: aggregatedArray.reduce((sum, item) => sum + item.hours, 0),
    mileage: aggregatedArray.reduce((sum, item) => sum + item.mileage, 0),
    expenses: aggregatedArray.reduce((sum, item) => sum + item.expenses, 0)
  };

  let html = `
    <h2>Monthly Volunteer Report for ${userName}</h2>
    <table style="border-collapse: collapse; width: 100%; margin-top: 20px;">
      <thead>
        <tr style="background-color: #f3f4f6;">
          <th style="border: 1px solid #ddd; padding: 8px; text-align: left;">Activity Code</th>
          <th style="border: 1px solid #ddd; padding: 8px; text-align: left;">Activity Name</th>
          <th style="border: 1px solid #ddd; padding: 8px; text-align: right;">Total Hours</th>
          <th style="border: 1px solid #ddd; padding: 8px; text-align: right;">Mileage</th>
          <th style="border: 1px solid #ddd; padding: 8px; text-align: right;">Non-Reimbursed $</th>
        </tr>
      </thead>
      <tbody>
  `;

  aggregatedArray.forEach(item => {
    html += `
      <tr>
        <td style="border: 1px solid #ddd; padding: 8px;">${item.code}</td>
        <td style="border: 1px solid #ddd; padding: 8px;">${item.name}</td>
        <td style="border: 1px solid #ddd; padding: 8px; text-align: right;">${item.hours.toFixed(2)}</td>
        <td style="border: 1px solid #ddd; padding: 8px; text-align: right;">${item.mileage.toFixed(0)}</td>
        <td style="border: 1px solid #ddd; padding: 8px; text-align: right;">$${item.expenses.toFixed(2)}</td>
      </tr>
    `;
  });

  html += `
      <tr style="background-color: #f9fafb; font-weight: bold;">
        <td colspan="2" style="border: 1px solid #ddd; padding: 8px;">Total</td>
        <td style="border: 1px solid #ddd; padding: 8px; text-align: right;">${totals.hours.toFixed(2)}</td>
        <td style="border: 1px solid #ddd; padding: 8px; text-align: right;">${totals.mileage.toFixed(0)}</td>
        <td style="border: 1px solid #ddd; padding: 8px; text-align: right;">$${totals.expenses.toFixed(2)}</td>
      </tr>
    </tbody>
  </table>
  
  <h3 style="margin-top: 30px;">Mission Details:</h3>
  `;

  aggregatedArray.forEach(item => {
    html += `
      <div style="margin-top: 15px; padding-left: 15px; border-left: 4px solid #3b82f6;">
        <strong>${item.code} - ${item.name}</strong>
        <ul style="margin-top: 10px;">
    `;
    item.missions.forEach(mission => {
      html += `<li>${mission}</li>`;
    });
    html += `
        </ul>
      </div>
    `;
  });

  return { html, totals };
}

function generateFlotillaSummary(flotillaActivities, flotillaName) {
  const aggregated = flotillaActivities.reduce((acc, activity) => {
    const code = activity.activity_code || 'Unknown';
    if (!acc[code]) {
      acc[code] = {
        code,
        name: ACTIVITY_CODES[code] || 'Unknown',
        hours: 0,
        mileage: 0,
        expenses: 0
      };
    }
    acc[code].hours += activity.total_hours || 0;
    acc[code].mileage += activity.mileage || 0;
    acc[code].expenses += activity.non_reimbursed_expenses || 0;
    return acc;
  }, {});

  const aggregatedArray = Object.values(aggregated);
  const totals = {
    hours: aggregatedArray.reduce((sum, item) => sum + item.hours, 0),
    mileage: aggregatedArray.reduce((sum, item) => sum + item.mileage, 0),
    expenses: aggregatedArray.reduce((sum, item) => sum + item.expenses, 0)
  };

  let html = `
    <h2>Flotilla Summary: ${flotillaName}</h2>
    <table style="border-collapse: collapse; width: 100%; margin-top: 20px;">
      <thead>
        <tr style="background-color: #f3f4f6;">
          <th style="border: 1px solid #ddd; padding: 8px; text-align: left;">Activity Code</th>
          <th style="border: 1px solid #ddd; padding: 8px; text-align: left;">Activity Name</th>
          <th style="border: 1px solid #ddd; padding: 8px; text-align: right;">Total Hours</th>
          <th style="border: 1px solid #ddd; padding: 8px; text-align: right;">Mileage</th>
          <th style="border: 1px solid #ddd; padding: 8px; text-align: right;">Non-Reimbursed $</th>
        </tr>
      </thead>
      <tbody>
  `;

  aggregatedArray.forEach(item => {
    html += `
      <tr>
        <td style="border: 1px solid #ddd; padding: 8px;">${item.code}</td>
        <td style="border: 1px solid #ddd; padding: 8px;">${item.name}</td>
        <td style="border: 1px solid #ddd; padding: 8px; text-align: right;">${item.hours.toFixed(2)}</td>
        <td style="border: 1px solid #ddd; padding: 8px; text-align: right;">${item.mileage.toFixed(0)}</td>
        <td style="border: 1px solid #ddd; padding: 8px; text-align: right;">$${item.expenses.toFixed(2)}</td>
      </tr>
    `;
  });

  html += `
      <tr style="background-color: #f9fafb; font-weight: bold;">
        <td colspan="2" style="border: 1px solid #ddd; padding: 8px;">Total</td>
        <td style="border: 1px solid #ddd; padding: 8px; text-align: right;">${totals.hours.toFixed(2)}</td>
        <td style="border: 1px solid #ddd; padding: 8px; text-align: right;">${totals.mileage.toFixed(0)}</td>
        <td style="border: 1px solid #ddd; padding: 8px; text-align: right;">$${totals.expenses.toFixed(2)}</td>
      </tr>
    </tbody>
  </table>
  `;

  return html;
}

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);

    // Get previous month date range
    const now = new Date();
    const lastMonth = subMonths(now, 1);
    const monthStart = startOfMonth(lastMonth);
    const monthEnd = endOfMonth(lastMonth);
    const monthName = format(monthStart, 'MMMM yyyy');

    // Fetch all data
    const [allActivities, allUsers, allFlotillas] = await Promise.all([
      base44.asServiceRole.entities.VolunteerActivity.list('-date'),
      base44.asServiceRole.entities.User.list(),
      base44.asServiceRole.entities.Flotilla.list()
    ]);

    // Filter activities for last month
    const monthActivities = allActivities.filter(a => {
      const activityDate = new Date(a.date);
      return activityDate >= monthStart && activityDate <= monthEnd;
    });

    if (monthActivities.length === 0) {
      return Response.json({ 
        message: 'No activities found for the previous month',
        month: monthName
      });
    }

    // Group activities by user
    const activitiesByUser = monthActivities.reduce((acc, activity) => {
      if (!acc[activity.created_by]) {
        acc[activity.created_by] = [];
      }
      acc[activity.created_by].push(activity);
      return acc;
    }, {});

    // Group activities by flotilla
    const activitiesByFlotilla = monthActivities.reduce((acc, activity) => {
      const flotillaId = activity.flotilla_id || 'unassigned';
      if (!acc[flotillaId]) {
        acc[flotillaId] = [];
      }
      acc[flotillaId].push(activity);
      return acc;
    }, {});

    const emailsSent = [];

    // Send individual reports to users
    for (const [userEmail, activities] of Object.entries(activitiesByUser)) {
      const user = allUsers.find(u => u.email === userEmail);
      if (!user) continue;

      const { html: userReportHtml } = generateUserReport(activities, user.full_name);
      
      const emailBody = `
        <div style="font-family: Arial, sans-serif; max-width: 800px; margin: 0 auto;">
          <h1>Volunteer Activity Report - ${monthName}</h1>
          <p>Hello ${user.full_name},</p>
          <p>Here is your volunteer activity report for ${monthName}:</p>
          ${userReportHtml}
          <p style="margin-top: 30px;">Thank you for your service!</p>
        </div>
      `;

      await base44.asServiceRole.integrations.Core.SendEmail({
        to: userEmail,
        subject: `Volunteer Activity Report - ${monthName}`,
        body: emailBody
      });

      emailsSent.push({ type: 'individual', email: userEmail, name: user.full_name });
    }

    // Send flotilla summary reports to FSO-FN
    for (const [flotillaId, activities] of Object.entries(activitiesByFlotilla)) {
      if (flotillaId === 'unassigned') continue;
      
      const flotilla = allFlotillas.find(f => f.id === flotillaId);
      if (!flotilla || !flotilla.fso_fn_email) continue;

      const flotillaSummaryHtml = generateFlotillaSummary(
        activities, 
        `${flotilla.flotilla_number} - ${flotilla.flotilla_name}`
      );

      const emailBody = `
        <div style="font-family: Arial, sans-serif; max-width: 800px; margin: 0 auto;">
          <h1>Flotilla Volunteer Summary - ${monthName}</h1>
          <p>Hello,</p>
          <p>Here is the volunteer activity summary for ${flotilla.flotilla_number} - ${flotilla.flotilla_name} for ${monthName}:</p>
          ${flotillaSummaryHtml}
          <p style="margin-top: 30px;">Total Members Reporting: ${new Set(activities.map(a => a.created_by)).size}</p>
        </div>
      `;

      await base44.asServiceRole.integrations.Core.SendEmail({
        to: flotilla.fso_fn_email,
        subject: `Flotilla ${flotilla.flotilla_number} Volunteer Summary - ${monthName}`,
        body: emailBody
      });

      emailsSent.push({ 
        type: 'flotilla', 
        email: flotilla.fso_fn_email, 
        flotilla: `${flotilla.flotilla_number} - ${flotilla.flotilla_name}` 
      });
    }

    return Response.json({
      success: true,
      month: monthName,
      emailsSent,
      statistics: {
        totalActivities: monthActivities.length,
        uniqueUsers: Object.keys(activitiesByUser).length,
        flotillasReported: Object.keys(activitiesByFlotilla).length - (activitiesByFlotilla.unassigned ? 1 : 0)
      }
    });

  } catch (error) {
    return Response.json({ 
      error: error.message,
      stack: error.stack 
    }, { status: 500 });
  }
});