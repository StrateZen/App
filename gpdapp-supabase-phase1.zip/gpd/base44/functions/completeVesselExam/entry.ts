import { createClientFromRequest } from 'npm:@base44/sdk@0.8.6';
import { PDFDocument, rgb, StandardFonts } from 'npm:pdf-lib@1.17.1';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();

    if (!user) {
      return Response.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const { exam_id } = await req.json();
    const exam = await base44.entities.VesselExam.get(exam_id);
    
    if (!exam) {
      return Response.json({ error: 'Exam not found' }, { status: 404 });
    }

    const formTypeLabels = {
      "7012_vsc": "Vessel Safety Check (7012)",
      "7012a_paddlecraft": "Paddle Craft VSC (7012A)",
      "7066_commercial": "Commercial Vessel (7066)",
      "7008_pwc": "PWC Facility (7008)",
      "7003_facility": "Vessel Facility (7003)",
    };

    let pdfDoc;

    if (exam.exam_type === '7012_vsc' || exam.exam_type === '7012a_paddlecraft') {
      // Load the official USCG Form 7012 template
      const templateUrl = 'https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/693829a377dc19b168d2f13c/daea55177_a7012_Rev_14_protected_fillabledpk.pdf';
      const templateResponse = await fetch(templateUrl);
      const templateBytes = await templateResponse.arrayBuffer();
      pdfDoc = await PDFDocument.load(templateBytes);
      
      const form = pdfDoc.getForm();
      
      // Fill text fields
      if (exam.exam_date) {
        form.getTextField('Date of VSC').setText(exam.exam_date);
      }

      // Decal Awarded checkboxes
      if (exam.decal_awarded !== undefined) {
        if (exam.decal_awarded) {
          form.getCheckBox('Decal Awarded_Yes').check();
        } else {
          form.getCheckBox('Decal Awarded_No').check();
        }
      }
      
      if (exam.owner_operator_name) {
        form.getTextField('OwnerOperator Name').setText(exam.owner_operator_name);
      }
      
      // Safe Boating Class checkboxes
      if (exam.safe_boating_class_attended !== undefined) {
        if (exam.safe_boating_class_attended) {
          form.getCheckBox('Check Box4').check();
        } else {
          form.getCheckBox('Check Box5').check();
        }
      }
      
      // Location
      if (exam.location_county) {
        form.getTextField('Location of VSC  County').setText(exam.location_county);
      }
      if (exam.location_state) {
        form.getTextField('State').setText(exam.location_state);
      }
      
      // Vessel info
      if (exam.registration_number) {
        form.getTextField('Documentation Number').setText(exam.registration_number);
      }
      
      if (exam.hin) {
        form.getTextField('HIN').setText(exam.hin);
      }
      
      // Vessel Length checkboxes
      if (exam.vessel_length) {
        const lengthMap = {
          '<16': '16',
          '16-25': '1625',
          '26-39': '2639',
          '40-65': '4065',
        };
        const lengthCheckbox = lengthMap[exam.vessel_length];
        if (lengthCheckbox) {
          form.getCheckBox(lengthCheckbox).check();
        }
      }
      
      // Powered By checkboxes
      if (exam.powered_by) {
        try {
          form.getCheckBox(exam.powered_by).check();
        } catch (e) {
          console.error(`Error checking powered_by ${exam.powered_by}:`, e.message);
        }
      }
      
      // Area of Operations
      if (exam.area_of_operations) {
        try {
          form.getCheckBox(exam.area_of_operations).check();
        } catch (e) {
          console.error(`Error checking area ${exam.area_of_operations}:`, e.message);
        }
      }
      
      // Vessel Type
      if (exam.vessel_type) {
        try {
          form.getCheckBox(exam.vessel_type).check();
        } catch (e) {
          console.error(`Error checking type ${exam.vessel_type}:`, e.message);
        }
      }
      
      // Requirements (1-15)
      for (let i = 1; i <= 15; i++) {
        const status = exam.requirements?.[i.toString()];
        if (status) {
          try {
            if (status === 'pass') {
              const yesField = form.getCheckBox(`Ck Yes Box${i === 9 ? ' 9' : i}`);
              yesField.check();
            } else if (status === 'fail') {
              const noField = form.getCheckBox(`Ck No Box${i === 2 || i === 3 || i === 4 || i === 5 || i === 6 || i === 7 || i === 9 || i === 10 || i === 11 || i === 12 || i === 13 ? ' ' + i : i}`);
              noField.check();
            } else if (status === 'na') {
              const naField = form.getCheckBox(`${i === 2 || i === 15 ? 'CK' : 'Ck'} NA Box${i === 2 || i === 15 ? ' ' + i : ' ' + i}`);
              naField.check();
            }
          } catch (e) {
            console.error(`Error checking requirement ${i}:`, e.message);
          }
        }
      }
      
      // Remarks
      if (exam.remarks) {
        try {
          form.getTextField('Remarks').setText(exam.remarks);
        } catch (e) {
          console.error('Error setting remarks:', e.message);
        }
      }
      
      // Examiner Information
      if (exam.examiner_name) {
        try {
          form.getTextField('Printed Name of the Examiner').setText(exam.examiner_name);
        } catch (e) {
          console.error('Error setting examiner name:', e.message);
        }
      }
      if (exam.examiner_number) {
        try {
          form.getTextField('Examiner Number').setText(exam.examiner_number);
        } catch (e) {
          console.error('Error setting examiner number:', e.message);
        }
      }
      
      // Recommended Items - all 22 items from the form
      if (exam.recommended_items) {
        const recommendedMapping = {
          'marine_radio': ['Yes Marine Radio', 'No Marine Radio'],
          'dewatering_device': ['Yes Dewatering Device', 'No Dewatering Device'],
          'mounted_fire_ext': ["Yes Mt'ed Fire Ext", "No Mt'ed Fire Ext"],
          'anchor_line': ['Yes Anchor  Line', 'No Anchor  Line'],
          'first_aid': ['Yes First Aid', 'No First Aid'],
          'inland_vds': ['Yes Inland VDS', 'No Inland VDS'],
          'capacity_cert': ['Yes CapacityCert', 'No CapacityCert'],
          'deck_hazards': ['Yes Deck Free', 'No Deck Free'],
          'electrical_systems': ['Yes Electrical', 'No Electrical'],
          'fuel_systems': ['Yes Fuel Systems', 'No Fuel Systems'],
          'galley_heating': ['Yes Galley', 'No Galley'],
          'accident_reporting': ['Yes Accident', 'No Accident'],
          'offshore_ops': ['Yes Offshore', 'No Offshore'],
          'carbon_monoxide': ['Yes CO', 'No CO'],
          'nautical_charts': ['Yes Charts', 'No Charts'],
          'fuel_mgmt': ['Yes Fuel Mgmt', 'No Fuel Mgmt'],
          'float_plan': ['Yes Float Plan', 'No Float Plan'],
          'boating_checklist': ['Yes Checklist', 'No Checklist'],
          'survival_tips': ['Yes Survival', 'No Survival'],
          'safe_boating_classes': ['Yes Classes', 'No Classes'],
          'marine_domain': ['Yes Domain', 'No Domain'],
          'insurance': ['Yes Insurance', 'No Insurance'],
          'tools_spare_parts': ['Yes Tools', 'No Tools'],
          'proper_ventilation': ['Yes Ventilation', 'No Ventilation'],
        };
        
        for (const [key, [yesField, noField]] of Object.entries(recommendedMapping)) {
          const value = exam.recommended_items[key];
          if (value === true) {
            try {
              form.getCheckBox(yesField).check();
            } catch (e) {
              console.error(`Error checking ${yesField}:`, e.message);
            }
          } else if (value === false) {
            try {
              form.getCheckBox(noField).check();
            } catch (e) {
              console.error(`Error checking ${noField}:`, e.message);
            }
          }
        }
      }
      
      // Flatten the form to make fields visible and non-editable
      form.flatten();
    } else {
      // For other exam types, create a basic PDF
      pdfDoc = await PDFDocument.create();
      const font = await pdfDoc.embedFont(StandardFonts.Helvetica);
      const boldFont = await pdfDoc.embedFont(StandardFonts.HelveticaBold);
      const page = pdfDoc.addPage([612, 792]);
      const { width, height } = page.getSize();
      
      // Header
      page.drawText('U.S. COAST GUARD AUXILIARY', {
        x: 50,
        y: height - 40,
        size: 14,
        font: boldFont,
        color: rgb(0, 0, 0.5),
      });
      
      page.drawText('VESSEL SAFETY CHECK (VSC)', {
        x: 50,
        y: height - 60,
        size: 12,
        font: boldFont,
      });

      // Draw simple exam data
      let yPos = height - 100;
      page.drawText(`Exam Date: ${exam.exam_date || 'N/A'}`, { x: 50, y: yPos, size: 10, font: font });
      yPos -= 20;
      page.drawText(`Owner: ${exam.owner_operator_name || 'N/A'}`, { x: 50, y: yPos, size: 10, font: font });
      yPos -= 20;
      page.drawText(`Examiner: ${exam.examiner_name || 'N/A'}`, { x: 50, y: yPos, size: 10, font: font });
    }
    
    const pdfBytes = await pdfDoc.save();
    const pdfFile = new File([pdfBytes], `vessel_exam_${exam_id}.pdf`, { type: 'application/pdf' });
    
    const uploadResponse = await base44.asServiceRole.integrations.Core.UploadFile({
      file: pdfFile
    });
    
    const pdfUrl = uploadResponse.file_url;

    await base44.asServiceRole.entities.VesselExam.update(exam_id, {
      status: 'completed',
      sent_date: new Date().toISOString(),
      pdf_url: pdfUrl,
      locked: true
    });

    const examinerEmail = user.email;
    if (examinerEmail) {
      const emailBody = `
Vessel exam completed successfully.

Exam Type: ${formTypeLabels[exam.exam_type]}
Owner: ${exam.owner_operator_name || 'N/A'}
Owner Email: ${exam.owner_email || 'N/A'}
Exam Date: ${exam.exam_date}
${exam.decal_awarded ? 'Status: PASSED - Decal Awarded ✓' : 'Status: Completed'}

Registration/Doc #: ${exam.registration_number || 'N/A'}
HIN: ${exam.hin || 'N/A'}

PDF Report: ${pdfUrl}

${exam.remarks ? `\nRemarks:\n${exam.remarks}` : ''}

Please share the PDF with the vessel owner at: ${exam.owner_email || 'owner email not provided'}
      `;

      await base44.asServiceRole.integrations.Core.SendEmail({
        to: examinerEmail,
        subject: `Vessel Exam Completed - ${exam.owner_operator_name}`,
        body: emailBody
      });
    }

    return Response.json({
      success: true,
      pdf_url: pdfUrl,
      message: 'Exam completed and emails sent successfully'
    });

  } catch (error) {
    console.error('Complete vessel exam error:', error);
    return Response.json({ 
      error: error.message || 'Failed to complete exam',
      details: error.toString()
    }, { status: 500 });
  }
});