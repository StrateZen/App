import { createClientFromRequest } from 'npm:@base44/sdk@0.8.4';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    
    const user = await base44.auth.me();
    if (!user) {
      return Response.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const { bank_transactions, account_id, tolerance_days = 3 } = await req.json();

    // Fetch app transactions for the account's flotilla
    const account = await base44.entities.BankAccount.filter({ id: account_id });
    if (!account || account.length === 0) {
      return Response.json({ error: 'Bank account not found' }, { status: 404 });
    }

    const flotillaId = account[0].flotilla_id;
    const appTransactions = await base44.entities.Transaction.filter({ 
      flotilla_id: flotillaId 
    });

    const matches = [];
    const unmatched_bank = [];
    const unmatched_app = [...appTransactions];

    // Matching algorithm
    bank_transactions.forEach(bankTrx => {
      const bankDate = new Date(bankTrx.date);
      const bankAmount = parseFloat(bankTrx.amount);

      let bestMatch = null;
      let bestScore = 0;

      appTransactions.forEach(appTrx => {
        // Skip if already matched
        if (matches.some(m => m.app_transaction?.id === appTrx.id)) {
          return;
        }

        const appDate = new Date(appTrx.transaction_date);
        const appAmount = parseFloat(appTrx.amount);

        // Calculate match score
        let score = 0;

        // Date proximity (within tolerance days)
        const daysDiff = Math.abs((bankDate - appDate) / (1000 * 60 * 60 * 24));
        if (daysDiff <= tolerance_days) {
          score += (tolerance_days - daysDiff) * 20;
        }

        // Amount match (exact match = 50 points, close match = scaled)
        const amountDiff = Math.abs(bankAmount - appAmount);
        if (amountDiff === 0) {
          score += 50;
        } else if (amountDiff < bankAmount * 0.01) { // Within 1%
          score += 40;
        } else if (amountDiff < bankAmount * 0.05) { // Within 5%
          score += 20;
        }

        // Transaction type match
        const bankType = bankTrx.type;
        const appType = appTrx.transaction_type;
        if (bankType === appType) {
          score += 20;
        }

        // Description similarity (basic)
        const bankDesc = (bankTrx.description || '').toLowerCase();
        const appDesc = (appTrx.description || '').toLowerCase();
        const appVendor = (appTrx.vendor_payee || '').toLowerCase();
        
        if (bankDesc && (appDesc.includes(bankDesc) || bankDesc.includes(appDesc) || 
            appVendor.includes(bankDesc) || bankDesc.includes(appVendor))) {
          score += 15;
        }

        if (score > bestScore && score >= 50) { // Minimum threshold
          bestScore = score;
          bestMatch = appTrx;
        }
      });

      if (bestMatch) {
        matches.push({
          bank_transaction: bankTrx,
          app_transaction: bestMatch,
          match_score: bestScore,
          match_quality: bestScore >= 85 ? 'high' : bestScore >= 70 ? 'medium' : 'low',
          discrepancies: calculateDiscrepancies(bankTrx, bestMatch)
        });

        // Remove from unmatched
        const idx = unmatched_app.findIndex(t => t.id === bestMatch.id);
        if (idx !== -1) unmatched_app.splice(idx, 1);
      } else {
        unmatched_bank.push(bankTrx);
      }
    });

    return Response.json({
      success: true,
      summary: {
        total_bank_transactions: bank_transactions.length,
        total_app_transactions: appTransactions.length,
        matched: matches.length,
        unmatched_bank: unmatched_bank.length,
        unmatched_app: unmatched_app.length
      },
      matches,
      unmatched_bank,
      unmatched_app
    });

  } catch (error) {
    console.error('Transaction matching error:', error);
    return Response.json({ error: error.message }, { status: 500 });
  }
});

function calculateDiscrepancies(bankTrx, appTrx) {
  const discrepancies = [];

  const bankAmount = parseFloat(bankTrx.amount);
  const appAmount = parseFloat(appTrx.amount);
  if (Math.abs(bankAmount - appAmount) > 0.01) {
    discrepancies.push({
      field: 'amount',
      bank_value: bankAmount,
      app_value: appAmount,
      difference: bankAmount - appAmount
    });
  }

  const bankDate = new Date(bankTrx.date).toISOString().split('T')[0];
  const appDate = new Date(appTrx.transaction_date).toISOString().split('T')[0];
  if (bankDate !== appDate) {
    discrepancies.push({
      field: 'date',
      bank_value: bankDate,
      app_value: appDate
    });
  }

  if (bankTrx.type !== appTrx.transaction_type) {
    discrepancies.push({
      field: 'type',
      bank_value: bankTrx.type,
      app_value: appTrx.transaction_type
    });
  }

  return discrepancies;
}