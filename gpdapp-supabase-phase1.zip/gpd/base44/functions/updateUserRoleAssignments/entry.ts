import { createClientFromRequest } from 'npm:@base44/sdk@0.8.25';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();

    if (!user) {
      return Response.json({ error: 'Unauthorized' }, { status: 401 });
    }

    // Only admins can update other users' roles
    const isAdmin = user.role === 'admin' || 
      (user.role_assignments || []).some(r => r.role === 'Super Admin');

    if (!isAdmin) {
      return Response.json({ error: 'Forbidden: Admin access required' }, { status: 403 });
    }

    const { userId, role_assignments, phone, auxid, address } = await req.json();

    if (!userId) {
      return Response.json({ error: 'userId is required' }, { status: 400 });
    }

    const updateData = {
      role_assignments: role_assignments || [],
    };
    if (phone !== undefined) updateData.phone = phone;
    if (auxid !== undefined) updateData.auxid = auxid;
    if (address !== undefined) updateData.address = address;

    const updated = await base44.asServiceRole.entities.User.update(userId, updateData);

    return Response.json({ success: true, user: updated });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});