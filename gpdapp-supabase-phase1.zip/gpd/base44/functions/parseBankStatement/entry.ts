import { createClientFromRequest } from 'npm:@base44/sdk@0.8.4';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    
    const user = await base44.auth.me();
    if (!user) {
      return Response.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const { file_url, format } = await req.json();

    // Fetch the file
    const fileResponse = await fetch(file_url);
    const fileContent = await fileResponse.text();

    let transactions = [];

    if (format === 'csv') {
      // Parse CSV format
      const lines = fileContent.split('\n').filter(line => line.trim());
      const headers = lines[0].toLowerCase().split(',').map(h => h.trim().replace(/"/g, ''));
      
      for (let i = 1; i < lines.length; i++) {
        const values = lines[i].split(',').map(v => v.trim().replace(/"/g, ''));
        const row = {};
        headers.forEach((header, idx) => {
          row[header] = values[idx];
        });

        // Try to identify common column patterns
        const dateCol = headers.find(h => h.includes('date') || h === 'posted') || headers[0];
        const descCol = headers.find(h => h.includes('desc') || h.includes('memo') || h.includes('detail')) || headers[1];
        const amountCol = headers.find(h => h.includes('amount') || h === 'debit' || h === 'credit') || headers[2];
        const typeCol = headers.find(h => h.includes('type'));

        const amount = parseFloat(row[amountCol]?.replace(/[^0-9.-]/g, '') || '0');
        
        if (amount !== 0) {
          transactions.push({
            date: row[dateCol],
            description: row[descCol] || '',
            amount: Math.abs(amount),
            type: amount > 0 ? 'income' : 'expense',
            raw: row
          });
        }
      }
    } else if (format === 'ofx') {
      // Basic OFX parsing
      const stmtTrn = fileContent.match(/<STMTTRN>[\s\S]*?<\/STMTTRN>/g) || [];
      
      stmtTrn.forEach(trn => {
        const dateMatch = trn.match(/<DTPOSTED>(\d{8})/);
        const amountMatch = trn.match(/<TRNAMT>([-\d.]+)/);
        const memoMatch = trn.match(/<MEMO>(.*?)(?:<|$)/);
        const nameMatch = trn.match(/<NAME>(.*?)(?:<|$)/);

        if (dateMatch && amountMatch) {
          const date = dateMatch[1];
          const formattedDate = `${date.slice(0,4)}-${date.slice(4,6)}-${date.slice(6,8)}`;
          const amount = parseFloat(amountMatch[1]);
          
          transactions.push({
            date: formattedDate,
            description: (nameMatch?.[1] || memoMatch?.[1] || '').trim(),
            amount: Math.abs(amount),
            type: amount > 0 ? 'income' : 'expense'
          });
        }
      });
    } else {
      return Response.json({ error: 'Unsupported format' }, { status: 400 });
    }

    return Response.json({ 
      success: true, 
      transactions,
      count: transactions.length 
    });

  } catch (error) {
    console.error('Bank statement parsing error:', error);
    return Response.json({ 
      error: error.message,
      details: 'Failed to parse bank statement. Please ensure the file format is correct.'
    }, { status: 500 });
  }
});