import { createClientFromRequest } from 'npm:@base44/sdk@0.8.4';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    
    const user = await base44.auth.me();
    if (!user) {
      return Response.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const { entity_type, entity_id, action, changes, flotilla_id } = await req.json();

    // Get IP and user agent from request headers
    const ip_address = req.headers.get('x-forwarded-for') || req.headers.get('x-real-ip') || 'unknown';
    const user_agent = req.headers.get('user-agent') || 'unknown';

    // Create audit log entry using service role
    const auditEntry = await base44.asServiceRole.entities.AuditLog.create({
      entity_type,
      entity_id,
      action,
      changed_by: user.email,
      changed_by_name: user.full_name || user.email,
      changes,
      flotilla_id: flotilla_id || null,
      ip_address: ip_address.split(',')[0].trim(), // Get first IP if multiple
      user_agent
    });

    return Response.json({ success: true, audit_id: auditEntry.id });
  } catch (error) {
    console.error('Audit logging error:', error);
    return Response.json({ error: error.message }, { status: 500 });
  }
});