import { createClientFromRequest } from 'npm:@base44/sdk@0.8.6';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();

    if (!user) {
      return Response.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const { exam_id } = await req.json();

    // Fetch the exam
    const exam = await base44.entities.VesselExam.get(exam_id);
    
    if (!exam) {
      return Response.json({ error: 'Exam not found' }, { status: 404 });
    }

    // If the exam already has a PDF, return that URL directly
    if (exam.pdf_url) {
      return Response.json({ 
        pdf_url: exam.pdf_url,
        message: 'Original exam PDF' 
      });
    }

    // If no PDF exists, call the complete function to generate it
    const completeResponse = await base44.functions.invoke('completeVesselExam', { exam_id });
    
    return Response.json(completeResponse.data);
    
    // Upload PDF
    const uploadResponse = await base44.asServiceRole.integrations.Core.UploadFile({
      file: pdfFile
    });
    
    const pdfUrl = uploadResponse.file_url;

    // Update exam with new PDF URL
    await base44.asServiceRole.entities.VesselExam.update(exam_id, {
      pdf_url: pdfUrl
    });

    return Response.json({
      success: true,
      pdf_url: pdfUrl
    });

  } catch (error) {
    console.error('Reprint vessel exam error:', error);
    return Response.json({ 
      error: error.message || 'Failed to reprint exam',
      details: error.toString()
    }, { status: 500 });
  }
});