import { createClientFromRequest } from 'npm:@base44/sdk@0.8.4';

Deno.serve(async (req) => {
    try {
        const base44 = createClientFromRequest(req);
        
        // Verify the requesting user is an admin
        const requestingUser = await base44.auth.me();
        if (!requestingUser || requestingUser.access_level !== 'super_admin') {
            return Response.json({ error: 'Unauthorized' }, { status: 401 });
        }

        const { userEmail, roleAssignments } = await req.json();

        if (!userEmail || !roleAssignments) {
            return Response.json({ error: 'Missing required fields' }, { status: 400 });
        }

        // Get all users using service role
        const users = await base44.asServiceRole.entities.User.filter({ email: userEmail });
        
        if (users.length === 0) {
            return Response.json({ error: 'User not found' }, { status: 404 });
        }

        const user = users[0];

        // Update user with new role assignments
        await base44.asServiceRole.entities.User.update(user.id, {
            role_assignments: roleAssignments
        });

        return Response.json({ 
            success: true, 
            message: 'User role assignments updated successfully',
            user: { email: userEmail, role_assignments: roleAssignments }
        });
    } catch (error) {
        return Response.json({ error: error.message }, { status: 500 });
    }
});